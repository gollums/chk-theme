<?php get_header();?>

<div class="container" id="main-container">
  	<div class="row">

      
  		<div class="col-el-3 col-3 col-s-12">
        <div class="dropdown">
          <div class="drop-noshow">
            <span><i class='fas fa-volleyball-ball'></i></span>
          </div>
          <div class="dropdown-content">
      			<div class="box">
                  <?php
                    if (is_single()) {
                      wp_nav_menu(
                        array(
                          'menu_class' => 'side-menu',
                          'menu' => 'front-page-side-menu',
                        )
                      ); 
                    }
                  ?>
              </div>
      			<div class="box">
    				<?php
    					if (is_single()) {
    						wp_nav_menu(
    							array(
    								'menu_class' => 'side-menu',
    								'menu' => 'Links',
    							)
    						);
    					}
    				?>
      			</div>
          </div>
        </div>
    	</div>


   	<div class="col-el-6 col-6 col-s-12">
      <div class="box">
      <h1><?php the_title();?></h1>
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post();
          ?>
                <img width = 90% src=<?php echo the_post_thumbnail_url();?>  > 
          <?php
					the_content();
					endwhile; else: ?>
				<p>Sorry, no posts matched your criteria.</p>
			<?php endif; ?>
    </div>
	</div>


	<div class="col-el-3 col-s-12">
		<div class="box">
        <div class="calendar">
          <?php echo do_shortcode('[calendar id="95"]'); ?>
        </div>
    </div>
    <div class="box">
      <a class="read-more" href=../../nyheter>Fler nyheter</a>
    </div>
    <div class="box">
      <a class="read-more" href=../herr/nyheter>Herr nyheter</a>
    </div>
    <div class="box">
      <a class="read-more" href=../dam/nyheter>Dam nyheter</a>   
    </div>
	</div>
</div>

<?php get_footer();?>