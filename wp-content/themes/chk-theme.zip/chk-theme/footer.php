<footer>

	<?php wp_footer();?>

	<div class="footer">
	<p> info@chalmershk.se </p>
	<!---<img src="<?php echo get_template_directory_uri(); ?>/images/footer.png" style=" width: 100%; height:100;"></a>--->

	</div>	

</footer>

</body>
</html>