<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		<script src='https://kit.fontawesome.com/a076d05399.js'></script>


		<div class="container" id="main-container">
			<?php wp_head();?>
			<div class="header">
				<?php 
					if (is_page(herr)) { ?>
						<a href="/chk"><img src="<?php echo get_template_directory_uri(); ?>/images/1200px/herr.svg" style="width: 100%;"></a>
					<?php } elseif (is_page(dam)) { ?>
						<a href="/chk"><img src="<?php echo get_template_directory_uri(); ?>/images/1200px/dam.svg" style="width: 100%;"></a>
					<?php } elseif (is_page(about)) { ?>
						<a href="/chk"><img src="<?php echo get_template_directory_uri(); ?>/images/1200px/omklubben.svg" style="width: 100%;"></a>
					<?php } elseif (is_page(contact)) { ?>
						<a href="/chk"><img src="<?php echo get_template_directory_uri(); ?>/images/1200px/kontakt.svg" style="width: 100%;"></a>
					<?php } else { 
						if(is_page() && get_the_title($post->post_parent) == 'Herr'){?>
							<a href="/chk"><img src="<?php echo get_template_directory_uri(); ?>/images/1200px/herr.svg" style="width: 100%;"></a>
						<?php } else if (is_page() && get_the_title($post->post_parent) == 'Dam') { ?>
							<a href="/chk"><img src="<?php echo get_template_directory_uri(); ?>/images/1200px/dam.svg" style="width: 100%;"></a>
						<?php } else{ ?>
						<a href="/chk"><img src="<?php echo get_template_directory_uri(); ?>/images/1200px/frontpage.svg" style="width: 100%; "></a>
					<?php }
						}
				?>	
			</div> 
		</div>
	
	</head>

<body <?php body_class();?>>
		<header class="sticky-top">
			<div class="container" id="main-container">
				<div class="header">
					<?php wp_nav_menu(
						array(
							'theme_location' => 'top-menu',
							'menu_class' => 'top-menu',
						)
					);?>
				</div>
			</div>
		</header>


